icaBackground
24 game - how to play:
Object of the game: Make the number 24 from the four numbers shown. You can add, subtract, multiply and divide. Use all four numbers on the card, but use each number only once. You do not have to use all four operations

24 game solver
This program acts as a solver. You input 4 numbers and this program will find all possible solutions for you.

Technology used
- Python
- Web programming using CS50 distribution code

How to run
go to 24gamesolver directory. Execute Flask run and go to the website provided by Flask.
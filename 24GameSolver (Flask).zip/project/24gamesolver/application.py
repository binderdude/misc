import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd, calc

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/result", methods=["GET", "POST"])
def buy():
    if request.method == "POST":
        N = []
        N.append(int(request.form.get("number1")))
        N.append(int(request.form.get("number2")))
        N.append(int(request.form.get("number3")))
        N.append(int(request.form.get("number4")))
        temp = [0,0,0,0]
        operator_list = ['+','-','*','/']
        operator = []
        number = []
        correct = []

        #Permutation of number
        for i in range(4):
            for j in range(4):
                if j == i:
                    continue
                for k in range(4):
                    if k == j or k == i:
                        continue
                    for l in range(4):
                        if l == k or l == j or l == i:
                            continue
                        temp1 = N[i]
                        temp2 = N[j]
                        temp3 = N[k]
                        temp4 = N[l]
                        temp = [temp1, temp2, temp3, temp4]
                        number.append(temp)

        #permutation of operator
        for i in range(4):
            for j in range(4):
                for k in range(4):
                    temp1 = operator_list[i]
                    temp2 = operator_list[j]
                    temp3 = operator_list[k]
                    oper_temp = [temp1, temp2, temp3]
                    operator.append(oper_temp)

        #working with bracket (5 conditions)
        for number_row in number:
            for oper_row in operator:
                result = 0

                # (a b) (c d)
                result = calc(calc(number_row[0], number_row[1], oper_row[0]), calc(number_row[2], number_row[3], oper_row[2]), oper_row[1])
                if abs(result - 24) < 0.001:
                    correct.append("({0} {1} {2}) {3} ({4} {5} {6})".format(number_row[0], oper_row[0], number_row[1], oper_row[1], number_row[2], oper_row[2], number_row[3]))

                # ((a b) c) d
                result = calc(number_row[0], number_row[1], oper_row[0])
                result = calc(result, number_row[2], oper_row[1])
                result = calc(result, number_row[3], oper_row[2])
                if abs(result - 24) < 0.001:
                    correct.append("(({0} {1} {2}) {3} {4}) {5} {6}".format(number_row[0], oper_row[0], number_row[1], oper_row[1], number_row[2], oper_row[2], number_row[3]))

                # (a (b c)) d
                result = calc(number_row[1], number_row[2], oper_row[1])
                result = calc(number_row[0], result, oper_row[0])
                result = calc(result, number_row[3], oper_row[2])
                if abs(result - 24) < 0.001:
                    correct.append("({0} {1} ({2} {3} {4})) {5} {6}".format(number_row[0], oper_row[0], number_row[1], oper_row[1], number_row[2], oper_row[2], number_row[3]))

                # a ((b c) d)
                result = calc(number_row[1], number_row[2], oper_row[1])
                result = calc(result, number_row[3], oper_row[2])
                result = calc(number_row[0], result,  oper_row[0])
                if abs(result - 24) < 0.001:
                    correct.append("{0} {1} (({2} {3} {4}) {5} {6})".format(number_row[0], oper_row[0], number_row[1], oper_row[1], number_row[2], oper_row[2], number_row[3]))                # a (b (c d))
                result = calc(number_row[2], number_row[3], oper_row[2])
                result = calc(number_row[1], result, oper_row[1])
                result = calc(number_row[0], result, oper_row[0])
                if abs(result - 24) < 0.001:
                    correct.append("{0} {1} ({2} {3} ({4} {5} {6}))".format(number_row[0], oper_row[0], number_row[1], oper_row[1], number_row[2], oper_row[2], number_row[3]))
        correct = list(dict.fromkeys(correct))
        return render_template("result.html", solutions=correct, total=len(correct))
    else:
        return redirect("/")

def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)